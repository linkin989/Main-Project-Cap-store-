import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { AdminUserValidationComponent } from './admin-user-validation/admin-user-validation.component';
import { AdminMerchantManageComponent } from './admin-merchant-manage/admin-merchant-manage.component';
import { AppRoutingModule } from './app-routing.module';
import { DeleteMerchantComponent } from './delete-merchant/delete-merchant.component';
import { ViewMerchantComponent } from './view-merchant/view-merchant.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { ServiceService } from './service.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ViewProductComponent } from './view-product/view-product.component';
import { SearchPipe } from './search.pipe';
import { ViewCustomerComponent } from './view-customer/view-customer.component';


@NgModule({
  declarations: [
    AppComponent,
    AdminUserValidationComponent,
    AdminMerchantManageComponent,
    DeleteMerchantComponent,
    ViewMerchantComponent,
    AddMerchantComponent,
    ViewProductComponent,
    SearchPipe,
    ViewCustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
