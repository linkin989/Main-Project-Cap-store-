import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Merchant } from '../Merchant';

@Component({
  selector: 'app-add-merchant',
  templateUrl: './add-merchant.component.html',
  styleUrls: ['./add-merchant.component.css']
})
export class AddMerchantComponent implements OnInit {

  [ x: string]: any;
  merchant:Merchant;
  createdFlag:boolean=false;
  service:ServiceService;
  router:Router;
  constructor(service:ServiceService, router: Router) {
    this.service=service;
    this.router=router
   }

  ngOnInit() {
  }
  add(data:any){
    let merchant=new Merchant(data.merchantId,data.userName,data.email,data.password,data.address,data.companyName,data.mobNo,data.aadharNo);
    //this.service.add(this.createdMerchant);
    this.service.add(merchant).then(response => {
      this.router.navigateByUrl('Merchant Notification');
      
     // this.router.navigateByUrl('display-merchants');
     // console.log(data.merchantId);
     // console.log(response.result.merchantId);
     // console.log(response.result.merchantId);
      }
      , err => {
      if (err.success != undefined && err.success == false) {
      alert(err.errors);
      }
      });
    }
  }