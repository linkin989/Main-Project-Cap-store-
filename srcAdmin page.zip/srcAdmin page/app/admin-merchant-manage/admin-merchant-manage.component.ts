import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '../../../node_modules/@angular/router';
import { Merchant } from '../Merchant';

@Component({
  selector: 'app-admin-merchant-manage',
  templateUrl: './admin-merchant-manage.component.html',
  styleUrls: ['./admin-merchant-manage.component.css']
})
export class AdminMerchantManageComponent implements OnInit {

  routes:Router;
  status;
  merchants:Merchant[]=[];
  service:ServiceService;
  column:string="merchantId";
  order:boolean=true;
  sort(column:string)
  {
    if(this.column==column)
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column
    }
  }
  setIndex(ii){
    this.order=ii;
    console.log
  }
  constructor(service:ServiceService, routes:Router) {
    this.service=service;
    this.routes=routes;
   }
  
   ngOnInit() {
    
     this.service.getInactiveMerchants().subscribe(data => this.merchants = data);
     
  }


 
  searchByID(merchantId1){
  this.service.searchByID(merchantId1).subscribe(data=>this.status=data);
}
  


}

