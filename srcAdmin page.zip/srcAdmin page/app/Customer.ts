export class Customer{
    customer_Id:number;
    customer_Name:string;
    customer_Password:string;
    //customer_ReEnterPassword:string;
    customer_HomeAddress:string;
    customer_ShippingAddress:string;
    customer_MobileNumber:string;
    customer_Email:string;
   //customer_Question:string;
    //customer_Answer:string;
    
    
      
          constructor(  customer_Id:number,customer_Name:string,customer_Password:string,customer_HomeAddress:string,
            customer_ShippingAddress:string,customer_MobileNumber:string,customer_Email:string)
            
          {
            this.customer_Id=customer_Id;
            this.customer_Name=customer_Name;
            this.customer_Password=customer_Password;
            this.customer_HomeAddress=customer_HomeAddress;
            this.customer_ShippingAddress=customer_ShippingAddress;
            this.customer_MobileNumber=customer_MobileNumber;
            this.customer_Email=customer_Email;
          }
        }
        