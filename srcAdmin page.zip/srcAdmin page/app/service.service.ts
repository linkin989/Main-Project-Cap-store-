import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {  Observable } from 'rxjs';
import { Merchant } from './Merchant';
import { Customer } from './Customer';
import { Product } from './Product';
import { ActivatedRoute } from '../../node_modules/@angular/router';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  url: string = "http://localhost:9000/manage";
  merchants:Merchant[]=[];
  customers:Customer[]=[];
  products:Product[]=[];
  routes:Router;

constructor(private http:HttpClient,routes:Router) { 
this.routes=routes;
}

private handleError(error: any): Promise<any> {
  return Promise.reject(error.error || error);
  }

getInactiveMerchants():Observable<Merchant []>
  {
    return this.http.get<Merchant[]>(this.url+"/viewInActiveMerchants");
  }
  getActiveMerchants():Observable<Merchant []>
  {
    return this.http.get<Merchant[]>(this.url+"/viewActiveMerchants");
  }
 


getCustomers():Observable<Customer []>
  {
    return this.http.get<Customer[]>(this.url+"/viewAllCustomer");
  }

  getProducts():Observable<Product []>
  {
    return this.http.get<Product[]>(this.url+"/viewAllProduct");
  }

//addMerchants(merchants)
 // {
    //by using this method we can add extra employee details in add employees page 
   // return this.http.post(this.url+"/addmerchants",merchants);

  //}
  
  add(merchants):Promise<any>{
    window.alert("Added Successfully");
    return this.http.post(this.url+"/addMerchants/",merchants)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
    }

  approve(merchantId:number)
  {
    return this.http.get(this.url + '/activeMerchants/'+merchantId);

  }
  deleteMerchant(merchantId:number) {
    
     return this.http.delete(this.url + '/deleteMerchants/'+merchantId);
     
    this.routes.navigateByUrl('Merchant Notification');
     
  }

  searchByID(merchantId1){
    return this.http.get(this.url + '/viewMerchantById/'+merchantId1);
  }
  

}
