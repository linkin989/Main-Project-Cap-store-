export class Product{
    productId:number;
    productType:string;
    productName:string;
      productPrice:number;
    productDescription:string;
    productAvailability:number;
  
    
    
      constructor( productId:number,productType:string,productName:string, productPrice:number,
        productDescription:string,  productAvailability:number)
          
          {
            this.productId=productId;
            this.productType=productType;
            this.productName=productName;
            this.productPrice=productPrice;
            this.productDescription=productDescription;
            this.productAvailability=productAvailability;
          
          }
        }
        