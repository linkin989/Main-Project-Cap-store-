import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-forget-password',
  templateUrl: './customer-forget-password.component.html',
  styleUrls: ['./customer-forget-password.component.css']
})
export class CustomerForgetPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
