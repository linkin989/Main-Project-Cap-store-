import { Component, OnInit } from '@angular/core';
import { CapstoreServiceService, Customer } from '../capstore-service.service';

@Component({
  selector: 'app-display-customer',
  templateUrl: './display-customer.component.html',
  styleUrls: ['./display-customer.component.css']
})
export class DisplayCustomerComponent implements OnInit {
  service:CapstoreServiceService;
  constructor(service:CapstoreServiceService) {
    this.service=service;
   }

   createCustomer:Customer[]=[]

  ngOnInit() {
    this.service.fetchCustomer();
    this.createCustomer=this.service.getCustomer();
  }


  delete(customerId:number){
    this.service.delete(customerId);
  }

  column:string="id";
  order:boolean=true;
  sort(column:string){
    if(this.column==column){
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column;
    }
  }

}
