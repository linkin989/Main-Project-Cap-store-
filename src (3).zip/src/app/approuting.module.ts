import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerHomepageComponent } from './customer-homepage/customer-homepage.component';
import {Routes,RouterModule} from '@angular/router';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerForgetPasswordComponent } from './customer-forget-password/customer-forget-password.component';
import { CustomerRegistrationComponent } from './customer-registration/customer-registration.component';
import { DisplayCustomerComponent } from './display-customer/display-customer.component';
const routes: Routes=
[
 {
 path:'',
 component: CustomerHomepageComponent,
 pathMatch:'full'

 },
 {
  path:'login',
  component: CustomerLoginComponent
 
  },
  {
    path:'forgot',
    component: CustomerForgetPasswordComponent
   
    },{
      path:'register',
      component: CustomerRegistrationComponent
     
      },{
          path:'display',
          component:DisplayCustomerComponent

      }
 
 ]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports:[RouterModule],
})
export class ApproutingModule { }
