import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { CustomerHomepageComponent } from './customer-homepage/customer-homepage.component';
import { ApproutingModule } from './approuting.module';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerRegistrationComponent } from './customer-registration/customer-registration.component';
import { CustomerForgetPasswordComponent } from './customer-forget-password/customer-forget-password.component';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import { CapstoreServiceService } from './capstore-service.service';
import { DisplayCustomerComponent } from './display-customer/display-customer.component';

@NgModule({
  declarations: [
    AppComponent,
    CustomerHomepageComponent,
    CustomerLoginComponent,
    CustomerRegistrationComponent,
    CustomerForgetPasswordComponent,
    DisplayCustomerComponent
  ],
  imports: [
    BrowserModule,
    ApproutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,CapstoreServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
