import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CapstoreServiceService {
  http:HttpClient;
  createCustomer:Customer[]=[];
  constructor(http:HttpClient) {
    this.http=http;
  }
  fetched:boolean=false;
  fetchCustomer(){
    this.http.get('./assets/createCustomer.json')
    
    .subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getCustomer():Customer[]{
    return this.createCustomer;
  }
  convert(data1:any){
    for(let o of data1){
      let e=new Customer(o.customerId,o.customerName,o.customerPassword,o.customerReEnterPassword,o.customerEmail,o.customerMobileNumber,o.customerHomeAddress,o.customerShippingAddress,o.customerQuestion,o.customerAnswer);
      this.createCustomer.push(e);
    }
  }
  delete(custId:number){
    let foundIndex:number=-1;
    for(let i=0;i<this.createCustomer.length;i++){
      let e=this.createCustomer[i];
      if(custId==e.customerId){
        foundIndex=1;
        break;
      }
    }
    this.createCustomer.splice(foundIndex,1);
  }
  add(e:Customer){
    this.createCustomer.push(e);
  }
}
export class Customer{
  customerId:number;
  customerName:string;
  customerPassword:string;
  customerReEnterPassword:string;
  customerEmail:string;
  customerMobileNumber:string;
  customerHomeAddress:string;
  customerShippingAddress:string;
  customerQuestion:string;
  customerAnswer:string;
  constructor(customerId:number,customerName:string,customerPassword:string,customerReEnterPassword:string,customerEmail:string,customerMobileNumber:string,customerHomeAddress:string,customerShippingAddress:string,customerQuestion:string,customerAnswer:string){
    this.customerId=customerId;
    this.customerName=customerName;
    this.customerPassword=customerPassword;
    this.customerReEnterPassword=customerReEnterPassword;
    this.customerEmail=customerEmail;
    this.customerMobileNumber=customerMobileNumber;
    this.customerHomeAddress=customerHomeAddress;
    this.customerShippingAddress=customerShippingAddress;
    this.customerQuestion=customerQuestion;
    this.customerAnswer=customerAnswer;
  }
}
