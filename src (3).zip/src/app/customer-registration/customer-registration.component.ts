import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapstoreServiceService, Customer } from '../capstore-service.service';

@Component({
  selector: 'app-customer-registration',
  templateUrl: './customer-registration.component.html',
  styleUrls: ['./customer-registration.component.css']
})
export class CustomerRegistrationComponent implements OnInit {

  router: Router;
  createCustomer:Customer;
  createdFlag:boolean=false;
  service:CapstoreServiceService;

  constructor(service:CapstoreServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  ngOnInit() {
  }

  add(data:any){
    this.createCustomer=new Customer(data.customerId,data.customerName,data.customerPassword,data.customerReEnterPassword,data.customerEmail,data.customerMobileNumber,data.customerHomeAddress,data.customerShippingAddress,data.customerQuestion,data.customerAnswer);
    this.service.add(this.createCustomer);
    this.router.navigate(['/login']);
    //this.router.navigateByUrl('login');
  }

}
