import { TestBed } from '@angular/core/testing';

import { CapstoreServiceService } from './capstore-service.service';

describe('CapstoreServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CapstoreServiceService = TestBed.get(CapstoreServiceService);
    expect(service).toBeTruthy();
  });
});
