import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-homepage',
  templateUrl: './customer-homepage.component.html',
  styleUrls: ['./customer-homepage.component.css']
})
export class CustomerHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
